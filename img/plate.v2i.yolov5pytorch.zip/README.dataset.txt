# plate > 2023-02-25 4:09pm
https://universe.roboflow.com/platepractice/plate-szsle

Provided by a Roboflow user
License: CC BY 4.0

